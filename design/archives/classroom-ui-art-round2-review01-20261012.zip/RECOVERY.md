恢复本审核记录；设计本体由archive-design-ui-art-round2-20261012与对应完整ZIP保留。
