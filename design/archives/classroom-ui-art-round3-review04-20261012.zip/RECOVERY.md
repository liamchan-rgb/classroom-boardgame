审核记录按本ZIP恢复；设计图按第三轮完整ZIP及archive-design-ui-art-round3-20261012恢复。
